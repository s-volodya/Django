// Avoid transformation text to link ie contentEditable mode
// https://stackoverflow.com/q/7556007/104380
document.execCommand("AutoUrlDetect", false, false);