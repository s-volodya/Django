from django.apps import AppConfig


class AdminuiConfig(AppConfig):
    name = 'adminUI'
