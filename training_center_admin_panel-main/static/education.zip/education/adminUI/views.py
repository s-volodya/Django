from django.shortcuts import render,redirect
from .models import Admins, Languages, Students, Groups, Teachers, TeacherLanguages, Subjects, SubSubjects, Lesson
from datetime import date, timedelta
from .forms import SubjectsForm
import json

def getallDays(ds,de,day):
    days = {
        "monday":7,
        "tuesday":1,
        "wednesday":2,
        "thursday":3,
        "friday":4,
        "saturday":5,
        "sunday":6
    }
    x = days[day]
    ds += timedelta(days = (x - ds.weekday() + 7) % 7)
    arr = []
    while ds <= de:
        arr.append([ds.year,ds.month,ds.day])
        ds += timedelta(days = 7)
    return arr
def addgroup(request):
    if 'login' in request.session:
        return render(request, "adminUI/addgroup.html",{"Teachers" : Teachers.objects.all(), "Students" : Students.objects.all(), "Languages" : Languages.objects.all()})
    else:
        return redirect("/login/")

def addTeacher(request):
    if 'login' in request.session:
        languagesNames = []
        languages = Languages.objects.all()
        for i in languages:
            languagesNames.append(i.name)
        if "first_name" in request.POST:
            teacher = Teachers()
            teacher.first_name = request.POST["first_name"]
            teacher.last_name = request.POST["last_name"]
            teacher.email = request.POST["email"]
            teacher.phone_number = request.POST["phone_number"]
            teacher.linkedin_link = request.POST["link"]
            teacher.monday_start = request.POST["monday_start"]
            teacher.monday_end = request.POST["monday_end"]
            teacher.tuesday_start = request.POST["tuesday_start"]
            teacher.tuesday_end = request.POST["tuesday_end"]
            teacher.wednesday_start = request.POST["wednesday_start"]
            teacher.wednesday_end = request.POST["wednesday_end"]
            teacher.thursday_start = request.POST["monday_start"]
            teacher.thursday_end = request.POST["thursday_end"]
            teacher.friday_start = request.POST["friday_start"]
            teacher.friday_end = request.POST["friday_end"]
            teacher.saturday_start = request.POST["saturday_start"]
            teacher.saturday_end = request.POST["saturday_end"]
            teacher.sunday_start = request.POST["sunday_start"]
            teacher.sunday_end = request.POST["sunday_end"]
            teacher.save()
            arr = request.POST['tags'].split('"value":')[1:]
            for i in arr :
                i = i.split('"')[1]
                tl = TeacherLanguages()
                tl.teacher = teacher
                tl.language = Languages.objects.filter(name = i)[0]
                tl.save()

        return render(request, "adminUI/addteacher.html",{"languages": languagesNames})
    else:
        return redirect("/login/")

def group(request,id):
    if "login" in request.session:
        group = Groups.objects.filter(id = id)

        if "newTimes" in request.POST:
            group.update(dayTimes = request.POST["newTimes"])

        members = Students.objects.filter(group = group[0])
        NNdays = []
        if group[0].monday_start:
            NNdays.append("monday")
        if group[0].tuesday_start:
            NNdays.append("tuesday")
        if group[0].wednesday_start:
            NNdays.append("wednesday")
        if group[0].thursday_start:
            NNdays.append("thursday")
        if group[0].friday_start:
            NNdays.append("friday")
        if group[0].saturday_start:
            NNdays.append("saturday")
        if group[0].sunday_start:
            NNdays.append("sunday")
        
        if "changes" in request.POST:
            changes = group[0].changes
            changes = request.POST["changes"] if not changes else changes + request.POST["changes"]
            Groups.objects.filter(id = id).update(changes = changes)

        changes = ''
        if group[0].changes:
            changesInString = group[0].changes
            
            changes = changesInString.split('|')
            changes = changes[:len(changes)-1]
            if changes[0]:
                for i in range(len(changes)):
                    changes[i] = [int(changes[i].split("-")[0]),int(changes[i].split("-")[1]),int(changes[i].split("-")[2])]
        
        ds = date(int(group[0].start[0:4]), int(group[0].start[5:7]), int(group[0].start[8:]))
        de = date(int(group[0].end[0:4]), int(group[0].end[5:7]), int(group[0].end[8:]))
        days = []
        
        for i in NNdays:
            days += getallDays(ds,de,i)
            
        if "monday_start" in request.POST:
            group.update(monday_start = request.POST["monday_start"], monday_end = request.POST["monday_end"], tuesday_start = request.POST["tuesday_start"], tuesday_end = request.POST["tuesday_end"], wednesday_start = request.POST["wednesday_start"], wednesday_end = request.POST["wednesday_end"], thursday_start = request.POST["thursday_start"], thursday_end = request.POST["thursday_end"], friday_start = request.POST["friday_start"], friday_end = request.POST["friday_end"], saturday_start = request.POST["saturday_start"], saturday_end = request.POST["saturday_end"], sunday_start = request.POST["sunday_start"], sunday_end = request.POST["sunday_end"])

        if changes:
            for i in changes:
                if( i in days):
                    days.remove(i)
                else:
                    days.append(i)
        start = []
        end = []
        start += [group[0].start[0:4], group[0].start[5:7], group[0].start[8:10]]
        end += [group[0].end[0:4], group[0].end[5:7], group[0].end[8:10]]
        return render(request, 'adminUI/group.html',{"members": members,"time": group[0].dayTimes ,"days" : json.dumps(days, indent = 4), "group" : group[0], "id" : id, "start" : start, "end" : end})
    else:
        return redirect("/login/")

def add(request):
    if request.POST:
        for i in request.POST :
            if i == "students" or i == "studentsadd":
                break

    if i == "studentsadd":
        student = Students()
        student.price = request.POST["price"]
        student.priceM = request.POST["priceM"]
        student.contract_end = request.POST["contract_end"]
        student.contract_start = request.POST["contract_start"]
        student.address = request.POST["address"]
        student.passport_type = request.POST["passport_type"]
        student.passport_number = request.POST["passport_number"]
        student.passportPic = request.POST["image"]
        student.phone_number = request.POST["phone_number"] 
        student.phone_number_code = request.POST["phone_number_code"]
        student.contract_number = request.POST["contract_number"]
        student.contract_number_code = request.POST["contract_number_code"]
        student.email = request.POST["email"]
        student.first_name = request.POST["first_name"]
        student.last_name = request.POST["last_name"]
        student.date_of_birth = request.POST["date_of_birth"]
        student.language = Languages.objects.filter(name = request.POST["language"])[0]
        student.save()
        return redirect("/students/")
    return render(request, 'adminUI/add.html', {"db" : i, "Students" : Students.objects.all(), "Languages" : Languages.objects.all()})


def edit(request):
    if "students" in request.POST:
        user = Students.objects.filter(id = request.POST["edit"])[0]
        return render(request, 'adminUI/edit.html',{'user' : user, "db": "students", "Students" : Students.objects.all(), "Languages" : Languages.objects.all()})
    elif "studentsedit" in request.POST:
        Students.objects.filter(id = request.POST["studentsedit"]).update(price = request.POST["price"], priceM = request.POST["priceM"], contract_end = request.POST["contract_end"], contract_start = request.POST["contract_start"], address = request.POST["address"], passport_type = request.POST["passport_type"], passport_number = request.POST["passport_number"], passportPic = request.POST["image"], phone_number = request.POST["phone_number"], phone_number_code = request.POST["phone_number_code"], contract_number = request.POST["contract_number"], contract_number_code = request.POST["contract_number_code"], email = request.POST["email"], first_name = request.POST["first_name"], last_name = request.POST["last_name"], date_of_birth = request.POST["date_of_birth"], language = Languages.objects.filter(name = request.POST["language"])[0])
        return redirect("/students/")
    return redirect("/students/",)

def groups(request):
    if "login" in request.session:
        if "group" in request.POST:
            Students.objects.filter(id = request.POST["user"]).update(group = (Groups.objects.get(id = request.POST["group"]) if request.POST["group"] != "rs" else None))
            
        if "groupName" in request.POST:
            group = Groups()
            group.name = request.POST["groupName"]
            group.start = request.POST["start"]
            group.end = request.POST["end"]
            group.language = Languages.objects.filter(name = request.POST['language'])[0]
            group.teacher = Teachers.objects.filter(first_name = request.POST['teacher'])[0]
            group.save()
        if "groupDel" in request.POST:
            Groups.objects.filter(id = request.POST["groupDel"]).delete()
        students = Students.objects.all()
        studentsWithoutGroup = Students.objects.filter(group = None)
        groups = Groups.objects.all()
        return render(request, 'adminUI/groups.html', { "students" : students, "groups" : groups, "studentsWithoutGroup": studentsWithoutGroup})
    else:
        return redirect("/login/")
def login(request):
    return render(request, 'adminUI/login.html')

def checkLogin(request):
    users = Admins.objects.all()
    username = request.POST["email"]
    password = request.POST["password"]
    userdata = (username,password)
    b = False
    for i in users:
        if userdata == i.userdata():
            b = True
    
    if b:
        request.session.set_expiry(1800)
        request.session['login'] = True
        return redirect("/students/")
    else:
        return render(request, 'adminUI/check.html')


def students(request):
    if "login" in request.session:
        students = Students.objects.all()
        for i in request.POST:
            if i != 'csrfmiddlewaretoken':
                Students.objects.filter(id=i).update(isArchived = True)
        studentdata = []
        for i in students:
            arr = i.data()[:6] + [i.data()[6].name if i.data()[6] else ""] + i.data()[7:]
            studentdata.append(arr)
        return render(request, 'adminUI/students.html', {'usersdata' : studentdata})
    else:
        return redirect("/login/")

def teachers(request):
    if "login" in request.session:
        teachers = Teachers.objects.all()
        for i in request.POST:
            if i != 'csrfmiddlewaretoken':
                Teachers.objects.filter(id=i).update(isArchived = True)
        studentdata = []

        for i in teachers:
            tlanguages = ""
            for j in TeacherLanguages.objects.filter(teacher = i):
                tlanguages += j.language.name + ", "
            
            tlanguages = tlanguages[:len(tlanguages)-2]
            studentdata.append(i.data() + [tlanguages])
        return render(request, 'adminUI/teachers.html', {'usersdata' : studentdata})
    else:
        return redirect("/login/")


def subjects(request,id):


    return render(request, 'adminUI/subjects.html',{ "height" : 5*15.5 + 551})

def CreateSubject(request):
    eror=''
    if request.method=="POST":
        form=SubjectsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('adminUI/subjects.html',{ "height" : 5*15.5 + 551})
    form=SubjectsForm()
    data={'form':form,}
    return render(request,'adminUI/create_subjects.html',data)


