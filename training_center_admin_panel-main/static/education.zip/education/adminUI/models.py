from django.db import models

# Create your models here.
class Admins(models.Model):
    id = models.AutoField('id', primary_key=True)
    email = models.CharField('email', max_length=30)
    password = models.CharField('password', max_length=20)
    first_name = models.CharField('name', max_length=20)
    last_name = models.CharField('last name', max_length=30)
    def data(self):
        return [self.id,self.email,self.password,self.first_name,self.last_name]
    def userdata(self):
        return (self.email,self.password)

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'


class Teachers(models.Model):
    id = models.AutoField('id', primary_key=True)
    first_name = models.CharField('name', max_length=20)
    last_name = models.CharField('last name', max_length=30)
    email = models.CharField('email', max_length=30, default="example@gmail.com")
    phone_number = models.CharField('phone_number', max_length=30, default="+374 93606060")
    linkedin_link = models.CharField('link', max_length=100)
    monday_start = models.CharField("monday_start", max_length  = 6, blank = True, null = True, default = "")
    monday_end = models.CharField("monday_end", max_length  = 6, blank = True, null = True, default = "")
    tuesday_start = models.CharField("tuesday_start", max_length  = 6, blank = True, null = True, default = "")
    tuesday_end = models.CharField("tuesday_end", max_length  = 6, blank = True, null = True, default = "")
    wednesday_start = models.CharField("wednesday_start", max_length  = 6, blank = True, null = True, default = "")
    wednesday_end = models.CharField("wednesday_end", max_length  = 6, blank = True, null = True, default = "")
    thursday_start = models.CharField("thursday_start", max_length  = 6, blank = True, null = True, default = "")
    thursday_end = models.CharField("thursday_end", max_length  = 6, blank = True, null = True, default = "")
    friday_start = models.CharField("friday_start", max_length  = 6, blank = True, null = True, default = "")
    friday_end = models.CharField("friday_end", max_length  = 6, blank = True, null = True, default = "")
    saturday_start = models.CharField("saturday_start", max_length  = 6, blank = True, null = True, default = "")
    saturday_end = models.CharField("saturday_end", max_length  = 6, blank = True, null = True, default = "")
    sunday_start = models.CharField("sunday", max_length  = 6, blank = True, null = True, default = "")
    sunday_end = models.CharField("sunday", max_length  = 6, blank = True, null = True, default = "")
    isArchived = models.BooleanField('isArchived', default = False)
    def data(self):
        return [self.id,self.first_name,self.last_name,self.linkedin_link,self.isArchived,self.email,self.phone_number]

class Subjects(models.Model):
    id = models.AutoField('id', primary_key=True)
    name = models.CharField('name', max_length = 20)

class SubSubjects(models.Model):
    name = models.CharField('name', max_length = 30)
    parentSubject = models.ForeignKey(Subjects, on_delete = models.CASCADE)

class Languages(models.Model):
    id = models.AutoField('id', primary_key=True)
    name = models.CharField('name', max_length = 20)
    parentSubject = models.ForeignKey(SubSubjects, on_delete = models.CASCADE)

    def data(self):
        return [self.id,self.name]
    
    class Meta:
        verbose_name = 'Language'
        verbose_name_plural = 'Languages'

class Lesson(models.Model):
    name = models.CharField('name', max_length = 50)
    Description = models.CharField('description', max_length = 300)
    language = models.ForeignKey(Languages, on_delete = models.CASCADE)

class TeacherLanguages(models.Model):
    language = models.ForeignKey(Languages, blank = True, null = True, on_delete = models.CASCADE)
    teacher = models.ForeignKey(Teachers, blank = True, null = True, on_delete = models.CASCADE)
    
class Groups(models.Model):
    id = models.AutoField('id', primary_key=True)
    name = models.CharField('name', max_length = 20)
    language = models.ForeignKey(Languages, blank = True, null = True, on_delete = models.SET_NULL)
    teacher = models.ForeignKey(Teachers, blank = True, null = True, on_delete = models.SET_NULL)
    start = models.CharField('start', max_length = 11)
    end = models.CharField('end', max_length = 11)
    monday_start = models.CharField("monday_start", max_length  = 6, blank = True, null = True, default = "")
    monday_end = models.CharField("monday_end", max_length  = 6, blank = True, null = True, default = "")
    tuesday_start = models.CharField("tuesday_start", max_length  = 6, blank = True, null = True, default = "")
    tuesday_end = models.CharField("tuesday_end", max_length  = 6, blank = True, null = True, default = "")
    wednesday_start = models.CharField("wednesday_start", max_length  = 6, blank = True, null = True, default = "")
    wednesday_end = models.CharField("wednesday_end", max_length  = 6, blank = True, null = True, default = "")
    thursday_start = models.CharField("thursday_start", max_length  = 6, blank = True, null = True, default = "")
    thursday_end = models.CharField("thursday_end", max_length  = 6, blank = True, null = True, default = "")
    friday_start = models.CharField("friday_start", max_length  = 6, blank = True, null = True, default = "")
    friday_end = models.CharField("friday_end", max_length  = 6, blank = True, null = True, default = "")
    saturday_start = models.CharField("saturday_start", max_length  = 6, blank = True, null = True, default = "")
    saturday_end = models.CharField("saturday_end", max_length  = 6, blank = True, null = True, default = "")
    sunday_start = models.CharField("sunday", max_length  = 6, blank = True, null = True, default = "")
    sunday_end = models.CharField("sunday", max_length  = 6, blank = True, null = True, default = "")
    changes = models.CharField("changes", max_length = 100000, blank = True, null = True, default = "")
    dayTimes = models.CharField("dayTimes", max_length = 100000, blank = True, null = True, default = "")
    class Meta:
        verbose_name = 'Group'
        verbose_name_plural = 'Groups'

class Students(models.Model):
    id = models.AutoField('id', primary_key=True)
    first_name = models.CharField('first_name', max_length = 20)
    last_name = models.CharField('last_name', max_length = 30)
    email = models.CharField('email', max_length = 50)
    phone_number = models.CharField('phone_number', max_length = 9)
    phone_number_code = models.CharField('phone_number_code', max_length = 4)
    contract_number = models.CharField('contract_number', max_length = 9)
    contract_number_code = models.CharField('contract_number_code', max_length = 4)
    passport_type = models.CharField('passport_type', max_length = 13)
    passport_number = models.CharField('passport_number', max_length = 13)
    address = models.CharField('addres', max_length = 25)
    date_of_birth = models.CharField('date_of_birth', max_length = 11)
    contract_start = models.CharField('contract_start', max_length = 11)
    contract_end = models.CharField('contract_end', max_length = 11)
    priceM = models.IntegerField("priceM")
    price = models.IntegerField("price")
    passportPic = models.CharField('image', max_length = 20000)
    language = models.ForeignKey(Languages, blank = True, null = True, on_delete = models.SET_NULL)
    group = models.ForeignKey(Groups, blank = True, null = True, on_delete = models.SET_NULL)
    isArchived = models.BooleanField('isArchived', default = False)

    def data(self):
        return [self.id,self.first_name,self.last_name,self.email,self.phone_number,self.date_of_birth,self.language,self.contract_number,self.passport_type,self.passport_number,self.address,self.contract_start,self.contract_end,self.priceM,self.price,self.passportPic,self.isArchived]
    class Meta:
        verbose_name = 'Student'
        verbose_name_plural = 'Students'


class SubSubjects1(models.Model):
    name = models.CharField('name', max_length = 30)
    parentSubject = models.ForeignKey(Subjects, on_delete = models.CASCADE)
