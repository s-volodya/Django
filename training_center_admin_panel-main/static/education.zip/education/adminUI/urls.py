from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('login/', views.login),
    path('checklogin/', views.checkLogin),
    path('students/', views.students),
    path('groups/', views.groups),
    path('groups/<id>/', views.group),
    path('add/', views.add),
    path('edit/', views.edit),
    path('addgroup/', views.addgroup),
    path('addteacher/', views.addTeacher),
    path('teachers/', views.teachers),
    path('subjects/<id>/', views.subjects),
    path('CreateSubject/',views.CreateSubject),

]
