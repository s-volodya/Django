from django.contrib import admin
from .models import Admins, Languages, Students, Groups, Teachers, TeacherLanguages, Subjects, SubSubjects, Lesson
# Register your models here.

admin.site.register(Admins)
admin.site.register(Languages)
admin.site.register(Students)
admin.site.register(Groups)
admin.site.register(Teachers)
admin.site.register(TeacherLanguages)
admin.site.register(Subjects)
admin.site.register(SubSubjects)
admin.site.register(Lesson)