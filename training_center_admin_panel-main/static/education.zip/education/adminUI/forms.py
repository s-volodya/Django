from.models import Subjects
from django.forms import ModelForm,TextInput

class SubjectsForm(ModelForm):
    class Meta:
        model=Subjects
        fields=['name']
        widgets={
            'name':TextInput(attrs={
                "class":'form-control',
                'placeholder':"Subjects Name"
            })

        }